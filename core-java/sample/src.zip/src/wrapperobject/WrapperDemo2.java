package wrapperobject;

public class WrapperDemo2 {

	public static void main(String[] args) {

		
		Integer a= new Integer(30);//wrapper obj a
		
		 
		int i=a.intValue(); //explicit
		
		
		//int j=a;// unboxing
		
		
		System.out.println(i);
		
	}

}
