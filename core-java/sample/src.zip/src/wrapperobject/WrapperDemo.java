package wrapperobject;




public class WrapperDemo {

	public static void main(String[] args) {
		
		
		int a=20; // primitive
		
		Integer i= Integer.valueOf(a); // Explicitly
		
		//Integer j= a;// autoboxing
		
		
		System.out.println(i);
		
		
		
		

	}

}
