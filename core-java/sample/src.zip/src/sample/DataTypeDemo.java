package sample;

public class DataTypeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		boolean b=false;
		
		char c='a';
		
	    byte by=10; //1 byte 0000 0000  1111 1111 8 bits
	    
	    short sh=20;
	    
	    int ii=40;
	    
	    long ll=80;
	    
	    float ff=10.10f;
	    
	    double dd=20.20d;
	    
	    System.out.println(b);
	    System.out.println(c);
	    System.out.println(by);
	    System.out.println(sh);
	    System.out.println(ii);
	    System.out.println(ll);
	    System.out.println(ff);
	    System.out.println(dd);
	}

}
