package sample;

public class HelloWorld { //class name
	//public gloabl access

	public static void main(String[] args) { // method name is main default method inbuild in jdk
		//static no object required
		//void no return 
		// TODO Auto-generated method stub
		System.out.println("Welcome to JAva learning");

	}

}
