package finalclassdemo;


final class Bike // final class cannot be inherited
{
	
}



class Vehicle// extends Bike
{
	
}
public class FinalClassDemo {

	public static void main(String[] args) {
	

	}

}
