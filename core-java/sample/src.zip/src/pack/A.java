package pack;

public class A {
	
	public  void msg() // default method or varibale cannot be accessed outside the package
	                   //proctected method can be accessed via inheritance
	{
		System.out.println("Message Hello");
	}

}


