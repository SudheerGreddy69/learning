package javastringpack;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		StringBuffer sb= new StringBuffer("Hello");
		
		sb.append(" Java");
		
		System.out.println(sb);

	}

}
