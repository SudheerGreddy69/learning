package javastringpack;

public class StringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuilder sb= new StringBuilder("Hello");
		
		sb.append(" world");
		
		System.out.println(sb);
	}

}
